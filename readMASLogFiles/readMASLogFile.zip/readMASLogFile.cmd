python readMASLogFile.py aard500.na.sas.com <userid> <password>
