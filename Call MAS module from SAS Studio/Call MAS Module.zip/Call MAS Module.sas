/* set the MAS module name */
%let decisionName= region_check;
/* set input and output/result table name */
%let input_table SASHELP.SHOES;
%let output_table work.region_check;

/* macro to run the MAS module for each row in the table */
%macro check_region(region);
	%global check_region;
	
	/* Put the JSON payload in external file */
	/* the structure og the payload looks like this: {"inputs":[{"name": "region_", "type": "string", "value": "Eastern Europe"}]} */
	filename json_in temp;
	proc json out= json_in;
		write open object;
	    	write values "inputs";
			write open array;
				write open object;
	    			write values "name" "region_";
	    			write values "type" "string";
	    			write values "value" "&Region";
				write close;
			write close;
		write close;
	run;
	
	/* execute module in MAS */
	filename decout temp;
	PROC HTTP
		method= "POST"   	
		url= &url
		in=json_in
		out= decout
	    oauth_bearer= sas_services;
	 	headers 
	    	"Content-Type"="application/json";
	run;
	
	/* read the output from the executed MAS module */
	libname decout json fileref=decout;
	data _null_;
		set DECOUT.OUTPUTS;
		call symputx('check_region', value);
	run;
%mend check_region;

/* get the number of row in the table in order to loop through the table */
proc sql;
select count(*) as cnt
  into :table_cnt
  from &input_table;
quit;

%macro call_MAS_module;
	/* get the local server name */
	data _null_;
		call symput('server', substr("&_baseurl", 1, prxmatch("\/SASStudio/\", "&_baseurl") - 1));
	run;
	
	/* build url to call module in MAS*/
	data _null_;
		url= cats('"', "&server", '/microanalyticScore/modules/', "&decisionName", '/steps/execute', '"');
		call symputx('url', url);
	run;

	%do _row_cnt=1 %to &table_cnt;
		data _null_;
			set &input_table;
			if _n_ = &_row_cnt then do;
				call symputx('Region', Region);
			end;
		run;

		/* call MAS module */
		%check_region(&Region);

		data work._tmp_out;
			length region $100;
			region= "&Region";
			region_check= &check_region;
		run;

		/* initilize output table table */
		%if &_row_cnt = 1 %then %do;
			proc append base=&output_table data=work._tmp_out(obs=0); 
			run;	
		%end;

		proc append base=&output_table data=work._tmp_out force nowarn ;
      	run;
	%end;

	proc delete data=work._tmp_out;
    run;
%mend call_MAS_module;

%call_MAS_module;


