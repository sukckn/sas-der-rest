############### Get SAS Token ##############################
# Logon Credentials. 
server= "viyatogo-singlenode"
uid= "viyademo01"
pwd= "lnxsas"
clientId= "sas.cli"
clientSecret= ""

# Call Viya REST API to get  token
loginCredentials={"grant_type":"password","username":uid,"password":pwd}
appBinding= clientId + ':' + clientSecret
appBinding64= base64.b64encode(bytes(appBinding, 'utf-8'))
url= "http://%s/SASLogon/oauth/token" % (server)

headers = {"Content-Type":"application/x-www-form-urlencoded", "Authorization":"Basic "}
headers["Authorization"]= "Basic " + appBinding64.decode('ascii') #appBinding64 is type bytes but need to convert to type str
response = requests.post(url, headers=headers, data=loginCredentials, verify=False)

if response.status_code == 503:
    print('Error receiving user token!')
    print("Server error 503.")
    sys.exit()

if response.status_code < 200 or response.status_code >= 300:
    print('Error receiving user token!')
    print(pd.DataFrame([response.json()]))
    sys.exit()
else:
    token= response.json()['access_token']

############### Process Data ##############################
# MAS Parameters
MasService= "region_check"

# Set JSON input structure here. 
inputData= {
  "inputs": [
    {"name": "region_", "type": "string", "value": None}
  ]
}

#output columns
region_col= []
validRegion_col= []

# Get SAS dataset into Python 
df_in= SAS.sd2df('SASHELP.SHOES(keep=region)')

#Loop through dataset and call MAS modult for each row in dataset
for region in df_in['Region']:
	# Assign input data here. Duplicate line below and adjust settings as necessary.
	inputData["inputs"][0]["value"]= region
	
	# Make Python dictionary into JSON object
	inputDataJSON= json.dumps(inputData)
	
	url= "http://%s/microanalyticScore/modules/%s/steps/execute" % (server, MasService)
	
	#execute module in MAS
	headers = {"Content-Type":"application/json"}
	headers["Authorization"]= "Bearer " + token
	response = requests.post(url, headers=headers, data=inputDataJSON, verify=False)
	
	if response.status_code == 503:
	    print("Server error 503.")
	    sys.exit()
	
	if response.status_code < 200 or response.status_code >= 300:
	    print('Error calling MAS service!')
	    print(response.json()['message'])
	    pd.options.display.max_colwidth = -1
	    print(pd.DataFrame(data= response.json()['details']))
	    sys.exit()
	
	#store return values from MAS module
	region_col.append(region)
	validRegion_col.append(response.json()['outputs'][0]['value'])

#put return values into dictionary
data_out= {}	
data_out['Region']= region_col
data_out['ValidRegion']= validRegion_col

#put output data into dataframe and out to Viya dataset
df_out= pd.DataFrame(data_out)
SAS.df2sd(df_out, 'work.region_ckeck')
	


	